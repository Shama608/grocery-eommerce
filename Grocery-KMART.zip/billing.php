<?php

$a = rand(1000,9999);
session_start();


if(isset($_POST['Submit'])){
$to = $_REQUEST['email'];
$subject = 'Transaction in progress';
$message = 'Payment in progress . Please enter the OTP below
OTP:'.$a; 
$from = 'sampeen608@gmail.com';
 
// Sending email
if(mail($to, $subject, $message)){
	
	 $_SESSION['otp'] = $a;
	 $_SESSION['email'] = $to;
  header("Location: https://sparkektha.000webhostapp.com/ecommerce/otp.php");
 

} else{
    echo 'Unable to send email. Please try again.';
}
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <title>Document</title>
</head>
<style>
body {
  background-color: #04bf94;
}
</style>
<body>


<form method="post" action="" style="margin-top: 0%;">
<div class="col-md-6">
<div class="container" style="margin-left: 120px;">
   <h1 style="margin-left: 95px;color: white">Shipping Details</h1>
    <div class="row">
    <div class="col-md-6">
  <div class="form-group">
    <label for="exampleInputEmail1">Name</label>
    <input type="text" class="form-control" id="name" name="name" aria-describedby="emailHelp" placeholder="Enter name" required>
  </div>

  <div class="form-group">
    <label for="exampleInputEmail1">Phone</label>
    <input type="text" class="form-control" id="phone" name="phone" aria-describedby="emailHelp" placeholder="Enter Phone Number" required>
   </div>

   <div class="form-group">
    <label for="exampleInputEmail1">Email</label>
    <input type="email" class="form-control" id="email" name="email" aria-describedby="emailHelp" placeholder="Enter email" required>
   </div>

  <div class="form-group">
    <label for="exampleInputEmail1">Address</label>
    <input type="text" class="form-control" id="address" name="address" aria-describedby="emailHelp" placeholder="Enter Address" required>
   </div>

   <div class="form-group">
    <label for="exampleInputEmail1">City</label>
    <input type="text" class="form-control" id="City" name="city" aria-describedby="emailHelp" placeholder="Enter City">
   </div>

   <div class="form-group">
    <label for="exampleInputEmail1">State</label>
    <input type="text" class="form-control" id="State" name="state" aria-describedby="emailHelp" placeholder="Enter State">
   </div>

   <div class="form-group">
    <label for="exampleInputEmail1">Pincode</label>
    <input type="text" class="form-control" id="pincode" name="pincode" aria-describedby="emailHelp" placeholder="Enter Pincode" required>
   </div>
  </div></div></div></div>

  <div class="col-md-6">
   <h1 style="color: white;margin-left: 120px;">Enter Card Details</h1>
   <div class="row">
    <div class="col" 
    style="background-color: lavender;
    width: 61%;
    height: 78vh;
    margin-top: 23px;
    border-radius: 5px;
    margin-bottom: 4px;
    margin-left: 85px;">
   <div class="row" style="padding-left:20px">
    <img style="margin-left: 50px;border-radius: 5px;margin-top: 20px;" src="images/paytm1.jpg">
      <div class="col-md-10" style="margin-left:25px;margin-top: 25px;">
      <div class="form-group">
    <label for="exampleInputEmail1">Card Number</label>
    <input type="number" class="form-control" id="name" name="cardnum" aria-describedby="emailHelp" placeholder="Enter name" required>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">CVV </label>
    <input type="number" class="form-control" id="name" name="cvv" aria-describedby="emailHelp" placeholder="Enter name"required>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Expiry Date</label>
    <input type="date" class="form-control" id="name" name="edate" aria-describedby="emailHelp" placeholder="Enter name" required>
  </div>

  <div class="row">
    <div class="col-md-4">
    <img style="border-radius: 5px;padding-left: 35px;" src="images/visa.jpg">
    </div>
    <div class="col-md-4">
    <img style="border-radius: 5px;padding-left: 6px;" src="images/amex.jpg">
    </div>
    <div class="col-md-4">
    <img style="border-radius: 5px;    margin-left: -27px;" src="images/mastercard.jpg">
    </div>
  </div>

</div>
</div>
    </div>

    </div>

   <button style="padding-right: 40px;
    padding-left: 40px;
    border: none;
    font-size: 20px;
    margin-left: -30px;" type="submit" name="Submit" class="btn btn-primary">PAY</button>
  </div>
  
</form>
</body>
</html>