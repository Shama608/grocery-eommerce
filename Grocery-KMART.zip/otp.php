<?php 

session_start();
$b = $_SESSION['otp'];
$c = $_SESSION['email'];


if(isset($_POST['SubmitButton'])){
$otpnum=$_POST['otpn'];
if($b==$otpnum){
    
$to = $_SESSION['email'];
$subject = 'Your Order is placed';
$message = 'Your Order is Confirmed'; 
$from = 'sampeen608@gmail.com';
if(mail($to, $subject, $message)){
	
echo "<script>
alert('Transaction is Successful,');
window.location.href='index.php';
</script>";
    
} else{
    echo 'Unable to process your order. Please try again.';
}
}
else{
    echo 'Unable to process your order. Please enter the correct OTP.';
}}
	
?>
<!DOCTYPE HTML>
<html>  
<body>

<form action ="" style="background-color: #6ad4d7;
    margin-right: 40%;
    padding: 20px;
    border-radius: 5px;
    margin-left: 35%;
    margin-top: 15%;" action="" method="post">

Enter OTP: <input style="border: none;
    border-radius: 2px;
    height: 30px;
    width: 215px;" type="text" name="otpn"><br>

<input style="border: none;
    border-radius: 2px;
    padding: 10px;
    background-color: #099709;
    color: white;" type="submit" name="SubmitButton">
</form>


</body>

</html>