<?php

$a = rand(1000,9999);
session_start();


if(isset($_POST['Submit'])){
$to = $_REQUEST['email'];
$subject = 'Transaction in progress';
$message = 'Payment in progress . Please enter the OTP below
OTP:'.$a; 
$from = 'sampeen608@gmail.com';
 
// Sending email
if(mail($to, $subject, $message)){
	
	 $_SESSION['otp'] = $a;
	 $_SESSION['email'] = $to;
  header("Location: https://sparkektha.000webhostapp.com/ecommerce/otp.php");
 

} else{
    echo 'Unable to send email. Please try again.';
}
}
?>

<!DOCTYPE HTML>
<html>  
<body>

<form style="background-color: #6ad4d7;
    margin-right: 40%;
    padding: 20px;
    border-radius: 5px;
    margin-left: 35%;
    margin-top: 15%;" action="" method="post">
Enter Email: <input style="border: none;
    border-radius: 2px;
    height: 30px;
    width: 215px;" type="email" name="email"><br>
<input style="border: none;
    border-radius: 2px;
    padding: 10px;
    background-color: #099709;
    color: white;" type="submit" name="Submit">
</form>