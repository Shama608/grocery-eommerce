<?php

require "config/constants.php";

$servername = 'localhost';
$username = 'id18669196_ecommerceapp';
$password = 'Ecommerce@123';
$db = 'id18669196_ecommerce';

// Create connection
$con = mysqli_connect($servername, $username, $password,$db);

// Check connection
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}


?>