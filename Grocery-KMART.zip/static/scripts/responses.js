function getBotResponse(input) {
    //rock paper scissors
    // if (input == "rock") {
    //     return "paper";
    // } else if (input == "paper") {
    //     return "scissors";
    // } else if (input == "scissors") {
    //     return "rock";
    // }

    // Simple responses
    // $response1="Fruits";
    // $response2="Vegetables";
    // $response3="SoftDrinks";

    if (input == "Fruits") {
        return "We have grapes, Apples and Bananas";
    } else if (input == "Vegetables") {
        return "We have Carrots, Onions and Tomatoes";
    } else if (input == "Soft Drinks") {
        return "We have Coke, Sprite and Fanta";
    } else if (input == "Spices") {
        return "Sorry! We are out of stock. We will be getting them soon!";
    } else if (input == "Pendrive") {
        return "Ah! We do not tock items othen than groceries";
    } else if (input == "Water bottle") {
        return "Ah! We do not stock items other than groceries";
    } else if (input == "Thank you for your support") {
        return "Your welcome! Have a nice day.";
    } else if (input == "Which brand product do you have?") {
        return "We have famous brands like Ilahi and Masso.";
    // } else if (input == "Hello") {
    //     return "Talk to you later!";
    // } else if (input == "goodbye") {
    //     return "Talk to you later!";
    } else {
        return "Try asking something else!";
    }
}